<?php
// Newsletter Subscription Handler
require_once 'db.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
    $email = trim($_POST['email']);

    if (empty($email)) {
        $response['message'] = 'Email is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response['message'] = 'Please enter a valid email address.';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO subscribers (email) VALUES (?)");
            $stmt->execute([$email]);
            $response['success'] = true;
            $response['message'] = 'Thank you for subscribing!';
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $response['message'] = 'You are already subscribed!';
            } else {
                $response['message'] = 'Something went wrong. Please try again.';
            }
        }
    }
} else {
    $response['message'] = 'Invalid request.';
}

echo json_encode($response);
?>
