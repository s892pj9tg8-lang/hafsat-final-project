<?php
session_start();
require_once '../includes/db.php';
requireLogin();

$flash = getFlash();

// Get current settings
$settings = [];
$stmt = $pdo->query("SELECT * FROM settings");
while ($row = $stmt->fetch()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $updates = [
        'site_title' => sanitize($_POST['site_title']),
        'site_description' => sanitize($_POST['site_description']),
        'contact_email' => sanitize($_POST['contact_email']),
        'contact_phone' => sanitize($_POST['contact_phone']),
        'contact_location' => sanitize($_POST['contact_location']),
    ];

    foreach ($updates as $key => $value) {
        $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?")
            ->execute([$key, $value, $value]);
    }

    setFlash('success', 'Settings updated successfully!');
    header('Location: settings.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings | Admin Panel</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <aside class="admin-sidebar" id="adminSidebar">
            <div class="sidebar-header">
                <a href="index.php" class="logo">Hafsat<span style="color: var(--admin-primary);">.</span>Dev</a>
                <button class="sidebar-toggle" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
            </div>
            <div class="sidebar-user">
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['admin_name']); ?>&background=00d4ff&color=fff" alt="Admin">
                <div class="sidebar-user-info">
                    <h4><?php echo htmlspecialchars($_SESSION['admin_name']); ?></h4>
                    <p><?php echo ucfirst($_SESSION['admin_role']); ?></p>
                </div>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="projects.php"><i class="fas fa-project-diagram"></i> Projects</a></li>
                    <li><a href="skills.php"><i class="fas fa-code"></i> Skills</a></li>
                    <li><a href="messages.php"><i class="fas fa-envelope"></i> Messages</a></li>
                    <li><a href="experience.php"><i class="fas fa-briefcase"></i> Experience</a></li>
                    <li><a href="services.php"><i class="fas fa-cogs"></i> Services</a></li>
                    <li><a href="testimonials.php"><i class="fas fa-quote-left"></i> Testimonials</a></li>
                    <li><a href="subscribers.php"><i class="fas fa-users"></i> Subscribers</a></li>
                    <li><a href="settings.php" class="active"><i class="fas fa-cog"></i> Settings</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>
        <div class="admin-overlay" id="adminOverlay" onclick="toggleSidebar()"></div>

        <main class="admin-main" id="adminMain">
            <div class="admin-topbar">
                <div class="topbar-title">
                    <h1>Settings</h1>
                    <p>Manage Site Configuration</p>
                </div>
                <div class="topbar-actions">
                    <a href="../index.html" target="_blank" class="topbar-btn"><i class="fas fa-external-link-alt"></i></a>
                </div>
            </div>

            <div class="admin-content">
                <?php if ($flash): ?>
                    <div class="admin-alert admin-alert-<?php echo $flash['type']; ?>">
                        <i class="fas fa-<?php echo $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                        <span><?php echo $flash['message']; ?></span>
                    </div>
                <?php endif; ?>

                <div class="data-card">
                    <div class="data-card-header">
                        <h3><i class="fas fa-cog" style="color: var(--admin-primary); margin-right: 0.5rem;"></i> Site Settings</h3>
                    </div>
                    <div style="padding: 2rem;">
                        <form class="admin-form" method="POST" action="">
                            <div class="form-group">
                                <label for="site_title">Site Title</label>
                                <input type="text" id="site_title" name="site_title" 
                                       value="<?php echo isset($settings['site_title']) ? htmlspecialchars($settings['site_title']) : 'Hafsat Samaila Abubakar | Software Engineer'; ?>">
                            </div>
                            <div class="form-group">
                                <label for="site_description">Site Description</label>
                                <textarea id="site_description" name="site_description"><?php echo isset($settings['site_description']) ? htmlspecialchars($settings['site_description']) : 'Portfolio of Hafsat Samaila Abubakar - Software Engineering Student & Full-Stack Developer'; ?></textarea>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="contact_email">Contact Email</label>
                                    <input type="email" id="contact_email" name="contact_email" 
                                           value="<?php echo isset($settings['contact_email']) ? htmlspecialchars($settings['contact_email']) : 'hafsat@example.com'; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="contact_phone">Contact Phone</label>
                                    <input type="text" id="contact_phone" name="contact_phone" 
                                           value="<?php echo isset($settings['contact_phone']) ? htmlspecialchars($settings['contact_phone']) : '+234 800 000 0000'; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="contact_location">Location</label>
                                <input type="text" id="contact_location" name="contact_location" 
                                       value="<?php echo isset($settings['contact_location']) ? htmlspecialchars($settings['contact_location']) : 'Nigeria'; ?>">
                            </div>
                            <button type="submit" class="btn-admin btn-admin-primary">
                                <i class="fas fa-save"></i> Save Settings
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Account Info -->
                <div class="data-card">
                    <div class="data-card-header">
                        <h3><i class="fas fa-user-shield" style="color: var(--admin-primary); margin-right: 0.5rem;"></i> Account Info</h3>
                    </div>
                    <div style="padding: 2rem;">
                        <div class="form-row">
                            <div class="form-group">
                                <label>Username</label>
                                <input type="text" value="admin" disabled style="background: rgba(255,255,255,0.03);">
                            </div>
                            <div class="form-group">
                                <label>Role</label>
                                <input type="text" value="Administrator" disabled style="background: rgba(255,255,255,0.03);">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Last Login</label>
                            <input type="text" value="<?php echo date('F d, Y h:i A'); ?>" disabled style="background: rgba(255,255,255,0.03);">
                        </div>
                        <p style="color: var(--admin-muted); font-size: 0.9rem; margin-top: 1rem;">
                            <i class="fas fa-info-circle"></i> Default credentials: <strong>admin / admin123</strong> — Change after first login for security.
                        </p>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script>
        function toggleSidebar() {
            document.getElementById('adminSidebar').classList.toggle('active');
            document.getElementById('adminOverlay').classList.toggle('active');
        }
    </script>
</body>
</html>
