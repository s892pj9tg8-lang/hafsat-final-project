<?php
// Admin Projects Management
session_start();
require_once '../includes/db.php';
requireLogin();

$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Handle Delete
if ($action === 'delete' && $id > 0) {
    $stmt = $pdo->prepare("DELETE FROM projects WHERE id = ?");
    $stmt->execute([$id]);
    setFlash('success', 'Project deleted successfully!');
    header('Location: projects.php');
    exit;
}

// Handle Add/Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize($_POST['title']);
    $slug = sanitize($_POST['slug']);
    $description = sanitize($_POST['description']);
    $technologies = sanitize($_POST['technologies']);
    $live_url = sanitize($_POST['live_url']);
    $github_url = sanitize($_POST['github_url']);
    $category = sanitize($_POST['category']);
    $featured = isset($_POST['featured']) ? 1 : 0;
    $sort_order = intval($_POST['sort_order']);

    if (empty($title) || empty($slug) || empty($description)) {
        $error = 'Title, slug, and description are required.';
    } else {
        if ($id > 0) {
            // Update
            $stmt = $pdo->prepare("UPDATE projects SET title=?, slug=?, description=?, technologies=?, live_url=?, github_url=?, category=?, featured=?, sort_order=? WHERE id=?");
            $stmt->execute([$title, $slug, $description, $technologies, $live_url, $github_url, $category, $featured, $sort_order, $id]);
            setFlash('success', 'Project updated successfully!');
        } else {
            // Insert
            $stmt = $pdo->prepare("INSERT INTO projects (title, slug, description, technologies, live_url, github_url, category, featured, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$title, $slug, $description, $technologies, $live_url, $github_url, $category, $featured, $sort_order]);
            setFlash('success', 'Project added successfully!');
        }
        header('Location: projects.php');
        exit;
    }
}

// Get project for edit
$project = null;
if ($action === 'edit' && $id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
    $stmt->execute([$id]);
    $project = $stmt->fetch();
}

// Get all projects
$projects = $pdo->query("SELECT * FROM projects ORDER BY sort_order, created_at DESC")->fetchAll();
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Projects | Admin Panel</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <aside class="admin-sidebar" id="adminSidebar">
            <div class="sidebar-header">
                <a href="index.php" class="logo">Hafsat<span style="color: var(--admin-primary);">.</span>Dev</a>
                <button class="sidebar-toggle" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
            </div>
            <div class="sidebar-user">
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['admin_name']); ?>&background=00d4ff&color=fff" alt="Admin">
                <div class="sidebar-user-info">
                    <h4><?php echo htmlspecialchars($_SESSION['admin_name']); ?></h4>
                    <p><?php echo ucfirst($_SESSION['admin_role']); ?></p>
                </div>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="projects.php" class="active"><i class="fas fa-project-diagram"></i> Projects</a></li>
                    <li><a href="skills.php"><i class="fas fa-code"></i> Skills</a></li>
                    <li><a href="messages.php"><i class="fas fa-envelope"></i> Messages</a></li>
                    <li><a href="experience.php"><i class="fas fa-briefcase"></i> Experience</a></li>
                    <li><a href="services.php"><i class="fas fa-cogs"></i> Services</a></li>
                    <li><a href="testimonials.php"><i class="fas fa-quote-left"></i> Testimonials</a></li>
                    <li><a href="subscribers.php"><i class="fas fa-users"></i> Subscribers</a></li>
                    <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>
        <div class="admin-overlay" id="adminOverlay" onclick="toggleSidebar()"></div>

        <main class="admin-main" id="adminMain">
            <div class="admin-topbar">
                <div class="topbar-title">
                    <h1>Manage Projects</h1>
                    <p><?php echo $action === 'add' ? 'Add New Project' : ($action === 'edit' ? 'Edit Project' : 'All Projects'); ?></p>
                </div>
                <div class="topbar-actions">
                    <a href="../index.html" target="_blank" class="topbar-btn" title="View Website"><i class="fas fa-external-link-alt"></i></a>
                </div>
            </div>

            <div class="admin-content">
                <?php if ($flash): ?>
                    <div class="admin-alert admin-alert-<?php echo $flash['type']; ?>">
                        <i class="fas fa-<?php echo $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                        <span><?php echo $flash['message']; ?></span>
                    </div>
                <?php endif; ?>

                <?php if (isset($error)): ?>
                    <div class="admin-alert admin-alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo $error; ?></span>
                    </div>
                <?php endif; ?>

                <?php if ($action === 'add' || $action === 'edit'): ?>
                    <!-- Add/Edit Form -->
                    <div class="data-card">
                        <div class="data-card-header">
                            <h3><?php echo $action === 'edit' ? 'Edit Project' : 'Add New Project'; ?></h3>
                            <a href="projects.php" class="btn-admin btn-admin-secondary" style="font-size: 0.85rem;">
                                <i class="fas fa-arrow-left"></i> Back to List
                            </a>
                        </div>
                        <div style="padding: 2rem;">
                            <form class="admin-form" method="POST" action="">
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="title">Project Title *</label>
                                        <input type="text" id="title" name="title" required 
                                               value="<?php echo $project ? htmlspecialchars($project['title']) : ''; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="slug">Slug *</label>
                                        <input type="text" id="slug" name="slug" required 
                                               value="<?php echo $project ? htmlspecialchars($project['slug']) : ''; ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="description">Description *</label>
                                    <textarea id="description" name="description" required><?php echo $project ? htmlspecialchars($project['description']) : ''; ?></textarea>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="category">Category</label>
                                        <input type="text" id="category" name="category" 
                                               value="<?php echo $project ? htmlspecialchars($project['category']) : 'Web Application'; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="sort_order">Sort Order</label>
                                        <input type="number" id="sort_order" name="sort_order" min="0" 
                                               value="<?php echo $project ? $project['sort_order'] : '0'; ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="technologies">Technologies (comma separated)</label>
                                    <input type="text" id="technologies" name="technologies" placeholder="PHP, MySQL, JavaScript, Bootstrap"
                                           value="<?php echo $project ? htmlspecialchars($project['technologies']) : ''; ?>">
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="live_url">Live Demo URL</label>
                                        <input type="url" id="live_url" name="live_url" placeholder="https://..."
                                               value="<?php echo $project ? htmlspecialchars($project['live_url']) : ''; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="github_url">GitHub URL</label>
                                        <input type="url" id="github_url" name="github_url" placeholder="https://github.com/..."
                                               value="<?php echo $project ? htmlspecialchars($project['github_url']) : ''; ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>
                                        <input type="checkbox" name="featured" value="1" <?php echo ($project && $project['featured']) ? 'checked' : ''; ?>>
                                        Featured Project
                                    </label>
                                </div>
                                <div style="display: flex; gap: 1rem;">
                                    <button type="submit" class="btn-admin btn-admin-primary">
                                        <i class="fas fa-save"></i> <?php echo $action === 'edit' ? 'Update' : 'Save'; ?> Project
                                    </button>
                                    <a href="projects.php" class="btn-admin btn-admin-secondary">Cancel</a>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Projects List -->
                    <div class="data-card">
                        <div class="data-card-header">
                            <h3><i class="fas fa-project-diagram" style="color: var(--admin-primary); margin-right: 0.5rem;"></i> All Projects</h3>
                            <div class="data-card-actions">
                                <div class="search-box">
                                    <i class="fas fa-search"></i>
                                    <input type="text" id="tableSearch" placeholder="Search projects...">
                                </div>
                                <a href="projects.php?action=add" class="btn-admin btn-admin-primary">
                                    <i class="fas fa-plus"></i> Add Project
                                </a>
                            </div>
                        </div>
                        <table class="admin-table" id="dataTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Title</th>
                                    <th>Category</th>
                                    <th>Technologies</th>
                                    <th>Featured</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($projects as $proj): ?>
                                    <tr>
                                        <td>#<?php echo $proj['id']; ?></td>
                                        <td><?php echo htmlspecialchars($proj['title']); ?></td>
                                        <td><?php echo htmlspecialchars($proj['category']); ?></td>
                                        <td><?php echo htmlspecialchars(substr($proj['technologies'], 0, 30)); ?><?php echo strlen($proj['technologies']) > 30 ? '...' : ''; ?></td>
                                        <td>
                                            <?php if ($proj['featured']): ?>
                                                <span class="badge badge-success"><i class="fas fa-star"></i></span>
                                            <?php else: ?>
                                                <span class="badge badge-info">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo date('M d, Y', strtotime($proj['created_at'])); ?></td>
                                        <td>
                                            <a href="projects.php?action=edit&id=<?php echo $proj['id']; ?>" class="btn-action btn-edit" title="Edit"><i class="fas fa-edit"></i></a>
                                            <a href="projects.php?action=delete&id=<?php echo $proj['id']; ?>" class="btn-action btn-delete" title="Delete" onclick="return confirmDelete('Are you sure you want to delete this project?')"><i class="fas fa-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <script>
        function toggleSidebar() {
            document.getElementById('adminSidebar').classList.toggle('active');
            document.getElementById('adminOverlay').classList.toggle('active');
        }
        function confirmDelete(msg) {
            return confirm(msg || 'Are you sure you want to delete this item?');
        }
        // Search functionality
        document.getElementById('tableSearch')?.addEventListener('keyup', function() {
            const filter = this.value.toLowerCase();
            const rows = document.querySelectorAll('#dataTable tbody tr');
            rows.forEach(row => {
                row.style.display = row.textContent.toLowerCase().includes(filter) ? '' : 'none';
            });
        });
    </script>
</body>
</html>
