<?php
session_start();
require_once '../includes/db.php';
requireLogin();

$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($action === 'delete' && $id > 0) {
    $pdo->prepare("DELETE FROM services WHERE id = ?")->execute([$id]);
    setFlash('success', 'Service deleted!');
    header('Location: services.php'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize($_POST['title']);
    $icon = sanitize($_POST['icon']);
    $description = sanitize($_POST['description']);
    $display_order = intval($_POST['display_order']);
    $is_active = isset($_POST['is_active']) ? 1 : 0;

    if (empty($title) || empty($description)) {
        $error = 'Title and description are required.';
    } else {
        if ($id > 0) {
            $pdo->prepare("UPDATE services SET title=?, icon=?, description=?, display_order=?, is_active=? WHERE id=?")
                ->execute([$title, $icon, $description, $display_order, $is_active, $id]);
            setFlash('success', 'Service updated!');
        } else {
            $pdo->prepare("INSERT INTO services (title, icon, description, display_order, is_active) VALUES (?, ?, ?, ?, ?)")
                ->execute([$title, $icon, $description, $display_order, $is_active]);
            setFlash('success', 'Service added!');
        }
        header('Location: services.php'); exit;
    }
}

$service = null;
if ($action === 'edit' && $id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM services WHERE id = ?");
    $stmt->execute([$id]);
    $service = $stmt->fetch();
}

$services = $pdo->query("SELECT * FROM services ORDER BY display_order, created_at DESC")->fetchAll();
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services | Admin Panel</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <aside class="admin-sidebar" id="adminSidebar">
            <div class="sidebar-header">
                <a href="index.php" class="logo">Hafsat<span style="color: var(--admin-primary);">.</span>Dev</a>
                <button class="sidebar-toggle" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
            </div>
            <div class="sidebar-user">
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['admin_name']); ?>&background=00d4ff&color=fff" alt="Admin">
                <div class="sidebar-user-info">
                    <h4><?php echo htmlspecialchars($_SESSION['admin_name']); ?></h4>
                    <p><?php echo ucfirst($_SESSION['admin_role']); ?></p>
                </div>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="projects.php"><i class="fas fa-project-diagram"></i> Projects</a></li>
                    <li><a href="skills.php"><i class="fas fa-code"></i> Skills</a></li>
                    <li><a href="messages.php"><i class="fas fa-envelope"></i> Messages</a></li>
                    <li><a href="experience.php"><i class="fas fa-briefcase"></i> Experience</a></li>
                    <li><a href="services.php" class="active"><i class="fas fa-cogs"></i> Services</a></li>
                    <li><a href="testimonials.php"><i class="fas fa-quote-left"></i> Testimonials</a></li>
                    <li><a href="subscribers.php"><i class="fas fa-users"></i> Subscribers</a></li>
                    <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>
        <div class="admin-overlay" id="adminOverlay" onclick="toggleSidebar()"></div>

        <main class="admin-main" id="adminMain">
            <div class="admin-topbar">
                <div class="topbar-title">
                    <h1>Services</h1>
                    <p><?php echo $action === 'add' ? 'Add New' : ($action === 'edit' ? 'Edit Service' : 'All Services'); ?></p>
                </div>
                <div class="topbar-actions">
                    <a href="../index.html" target="_blank" class="topbar-btn"><i class="fas fa-external-link-alt"></i></a>
                </div>
            </div>

            <div class="admin-content">
                <?php if ($flash): ?>
                    <div class="admin-alert admin-alert-<?php echo $flash['type']; ?>">
                        <i class="fas fa-<?php echo $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                        <span><?php echo $flash['message']; ?></span>
                    </div>
                <?php endif; ?>

                <?php if (isset($error)): ?>
                    <div class="admin-alert admin-alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo $error; ?></span>
                    </div>
                <?php endif; ?>

                <?php if ($action === 'add' || $action === 'edit'): ?>
                    <div class="data-card">
                        <div class="data-card-header">
                            <h3><?php echo $action === 'edit' ? 'Edit Service' : 'Add Service'; ?></h3>
                            <a href="services.php" class="btn-admin btn-admin-secondary" style="font-size: 0.85rem;"><i class="fas fa-arrow-left"></i> Back</a>
                        </div>
                        <div style="padding: 2rem;">
                            <form class="admin-form" method="POST" action="">
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="title">Service Title *</label>
                                        <input type="text" id="title" name="title" required value="<?php echo $service ? htmlspecialchars($service['title']) : ''; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="icon">Icon Class</label>
                                        <input type="text" id="icon" name="icon" placeholder="fas fa-code" value="<?php echo $service ? htmlspecialchars($service['icon']) : 'fas fa-code'; ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="description">Description *</label>
                                    <textarea id="description" name="description" required><?php echo $service ? htmlspecialchars($service['description']) : ''; ?></textarea>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="display_order">Display Order</label>
                                        <input type="number" id="display_order" name="display_order" min="0" value="<?php echo $service ? $service['display_order'] : '0'; ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>
                                        <input type="checkbox" name="is_active" value="1" <?php echo (!$service || $service['is_active']) ? 'checked' : ''; ?>>
                                        Active
                                    </label>
                                </div>
                                <div style="display: flex; gap: 1rem;">
                                    <button type="submit" class="btn-admin btn-admin-primary"><i class="fas fa-save"></i> <?php echo $action === 'edit' ? 'Update' : 'Save'; ?></button>
                                    <a href="services.php" class="btn-admin btn-admin-secondary">Cancel</a>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="data-card">
                        <div class="data-card-header">
                            <h3><i class="fas fa-cogs" style="color: var(--admin-primary); margin-right: 0.5rem;"></i> Services</h3>
                            <div class="data-card-actions">
                                <div class="search-box">
                                    <i class="fas fa-search"></i>
                                    <input type="text" id="tableSearch" placeholder="Search...">
                                </div>
                                <a href="services.php?action=add" class="btn-admin btn-admin-primary"><i class="fas fa-plus"></i> Add</a>
                            </div>
                        </div>
                        <table class="admin-table" id="dataTable">
                            <thead>
                                <tr><th>ID</th><th>Title</th><th>Icon</th><th>Status</th><th>Actions</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($services as $s): ?>
                                    <tr>
                                        <td>#<?php echo $s['id']; ?></td>
                                        <td><?php echo htmlspecialchars($s['title']); ?></td>
                                        <td><i class="<?php echo htmlspecialchars($s['icon']); ?>"></i></td>
                                        <td><?php echo $s['is_active'] ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>'; ?></td>
                                        <td>
                                            <a href="services.php?action=edit&id=<?php echo $s['id']; ?>" class="btn-action btn-edit"><i class="fas fa-edit"></i></a>
                                            <a href="services.php?action=delete&id=<?php echo $s['id']; ?>" class="btn-action btn-delete" onclick="return confirmDelete()"><i class="fas fa-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
    <script>
        function toggleSidebar() {
            document.getElementById('adminSidebar').classList.toggle('active');
            document.getElementById('adminOverlay').classList.toggle('active');
        }
        function confirmDelete() { return confirm('Are you sure?'); }
        document.getElementById('tableSearch')?.addEventListener('keyup', function() {
            const filter = this.value.toLowerCase();
            document.querySelectorAll('#dataTable tbody tr').forEach(row => {
                row.style.display = row.textContent.toLowerCase().includes(filter) ? '' : 'none';
            });
        });
    </script>
</body>
</html>
