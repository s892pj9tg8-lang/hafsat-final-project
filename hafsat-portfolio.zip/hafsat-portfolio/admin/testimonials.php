<?php
session_start();
require_once '../includes/db.php';
requireLogin();

$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($action === 'delete' && $id > 0) {
    $pdo->prepare("DELETE FROM testimonials WHERE id = ?")->execute([$id]);
    setFlash('success', 'Testimonial deleted!');
    header('Location: testimonials.php'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name']);
    $role = sanitize($_POST['role']);
    $company = sanitize($_POST['company']);
    $content = sanitize($_POST['content']);
    $rating = intval($_POST['rating']);
    $is_active = isset($_POST['is_active']) ? 1 : 0;

    if (empty($name) || empty($content)) {
        $error = 'Name and content are required.';
    } else {
        if ($id > 0) {
            $pdo->prepare("UPDATE testimonials SET name=?, role=?, company=?, content=?, rating=?, is_active=? WHERE id=?")
                ->execute([$name, $role, $company, $content, $rating, $is_active, $id]);
            setFlash('success', 'Testimonial updated!');
        } else {
            $pdo->prepare("INSERT INTO testimonials (name, role, company, content, rating, is_active) VALUES (?, ?, ?, ?, ?, ?)")
                ->execute([$name, $role, $company, $content, $rating, $is_active]);
            setFlash('success', 'Testimonial added!');
        }
        header('Location: testimonials.php'); exit;
    }
}

$testimonial = null;
if ($action === 'edit' && $id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM testimonials WHERE id = ?");
    $stmt->execute([$id]);
    $testimonial = $stmt->fetch();
}

$testimonials = $pdo->query("SELECT * FROM testimonials ORDER BY created_at DESC")->fetchAll();
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Testimonials | Admin Panel</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <aside class="admin-sidebar" id="adminSidebar">
            <div class="sidebar-header">
                <a href="index.php" class="logo">Hafsat<span style="color: var(--admin-primary);">.</span>Dev</a>
                <button class="sidebar-toggle" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
            </div>
            <div class="sidebar-user">
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['admin_name']); ?>&background=00d4ff&color=fff" alt="Admin">
                <div class="sidebar-user-info">
                    <h4><?php echo htmlspecialchars($_SESSION['admin_name']); ?></h4>
                    <p><?php echo ucfirst($_SESSION['admin_role']); ?></p>
                </div>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="projects.php"><i class="fas fa-project-diagram"></i> Projects</a></li>
                    <li><a href="skills.php"><i class="fas fa-code"></i> Skills</a></li>
                    <li><a href="messages.php"><i class="fas fa-envelope"></i> Messages</a></li>
                    <li><a href="experience.php"><i class="fas fa-briefcase"></i> Experience</a></li>
                    <li><a href="services.php"><i class="fas fa-cogs"></i> Services</a></li>
                    <li><a href="testimonials.php" class="active"><i class="fas fa-quote-left"></i> Testimonials</a></li>
                    <li><a href="subscribers.php"><i class="fas fa-users"></i> Subscribers</a></li>
                    <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>
        <div class="admin-overlay" id="adminOverlay" onclick="toggleSidebar()"></div>

        <main class="admin-main" id="adminMain">
            <div class="admin-topbar">
                <div class="topbar-title">
                    <h1>Testimonials</h1>
                    <p><?php echo $action === 'add' ? 'Add New' : ($action === 'edit' ? 'Edit' : 'All Testimonials'); ?></p>
                </div>
                <div class="topbar-actions">
                    <a href="../index.html" target="_blank" class="topbar-btn"><i class="fas fa-external-link-alt"></i></a>
                </div>
            </div>

            <div class="admin-content">
                <?php if ($flash): ?>
                    <div class="admin-alert admin-alert-<?php echo $flash['type']; ?>">
                        <i class="fas fa-<?php echo $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                        <span><?php echo $flash['message']; ?></span>
                    </div>
                <?php endif; ?>

                <?php if (isset($error)): ?>
                    <div class="admin-alert admin-alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo $error; ?></span>
                    </div>
                <?php endif; ?>

                <?php if ($action === 'add' || $action === 'edit'): ?>
                    <div class="data-card">
                        <div class="data-card-header">
                            <h3><?php echo $action === 'edit' ? 'Edit Testimonial' : 'Add Testimonial'; ?></h3>
                            <a href="testimonials.php" class="btn-admin btn-admin-secondary" style="font-size: 0.85rem;"><i class="fas fa-arrow-left"></i> Back</a>
                        </div>
                        <div style="padding: 2rem;">
                            <form class="admin-form" method="POST" action="">
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="name">Name *</label>
                                        <input type="text" id="name" name="name" required value="<?php echo $testimonial ? htmlspecialchars($testimonial['name']) : ''; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="role">Role/Title</label>
                                        <input type="text" id="role" name="role" value="<?php echo $testimonial ? htmlspecialchars($testimonial['role']) : ''; ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="company">Company</label>
                                    <input type="text" id="company" name="company" value="<?php echo $testimonial ? htmlspecialchars($testimonial['company']) : ''; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="content">Testimonial Content *</label>
                                    <textarea id="content" name="content" required><?php echo $testimonial ? htmlspecialchars($testimonial['content']) : ''; ?></textarea>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="rating">Rating (1-5)</label>
                                        <input type="number" id="rating" name="rating" min="1" max="5" value="<?php echo $testimonial ? $testimonial['rating'] : '5'; ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>
                                        <input type="checkbox" name="is_active" value="1" <?php echo (!$testimonial || $testimonial['is_active']) ? 'checked' : ''; ?>>
                                        Active
                                    </label>
                                </div>
                                <div style="display: flex; gap: 1rem;">
                                    <button type="submit" class="btn-admin btn-admin-primary"><i class="fas fa-save"></i> <?php echo $action === 'edit' ? 'Update' : 'Save'; ?></button>
                                    <a href="testimonials.php" class="btn-admin btn-admin-secondary">Cancel</a>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="data-card">
                        <div class="data-card-header">
                            <h3><i class="fas fa-quote-left" style="color: var(--admin-primary); margin-right: 0.5rem;"></i> Testimonials</h3>
                            <div class="data-card-actions">
                                <div class="search-box">
                                    <i class="fas fa-search"></i>
                                    <input type="text" id="tableSearch" placeholder="Search...">
                                </div>
                                <a href="testimonials.php?action=add" class="btn-admin btn-admin-primary"><i class="fas fa-plus"></i> Add</a>
                            </div>
                        </div>
                        <table class="admin-table" id="dataTable">
                            <thead>
                                <tr><th>ID</th><th>Name</th><th>Role</th><th>Rating</th><th>Status</th><th>Actions</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($testimonials as $t): ?>
                                    <tr>
                                        <td>#<?php echo $t['id']; ?></td>
                                        <td><?php echo htmlspecialchars($t['name']); ?></td>
                                        <td><?php echo htmlspecialchars($t['role']); ?></td>
                                        <td><?php echo str_repeat('<i class="fas fa-star" style="color: var(--admin-warning);"></i> ', $t['rating']); ?></td>
                                        <td><?php echo $t['is_active'] ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>'; ?></td>
                                        <td>
                                            <a href="testimonials.php?action=edit&id=<?php echo $t['id']; ?>" class="btn-action btn-edit"><i class="fas fa-edit"></i></a>
                                            <a href="testimonials.php?action=delete&id=<?php echo $t['id']; ?>" class="btn-action btn-delete" onclick="return confirmDelete()"><i class="fas fa-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
    <script>
        function toggleSidebar() {
            document.getElementById('adminSidebar').classList.toggle('active');
            document.getElementById('adminOverlay').classList.toggle('active');
        }
        function confirmDelete() { return confirm('Are you sure?'); }
        document.getElementById('tableSearch')?.addEventListener('keyup', function() {
            const filter = this.value.toLowerCase();
            document.querySelectorAll('#dataTable tbody tr').forEach(row => {
                row.style.display = row.textContent.toLowerCase().includes(filter) ? '' : 'none';
            });
        });
    </script>
</body>
</html>
