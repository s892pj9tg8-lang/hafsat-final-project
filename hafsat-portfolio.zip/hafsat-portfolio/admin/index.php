<?php
// Admin Dashboard
session_start();
require_once '../includes/db.php';
requireLogin();

// Get statistics
$stats = [];
$stats['projects'] = $pdo->query("SELECT COUNT(*) FROM projects")->fetchColumn();
$stats['skills'] = $pdo->query("SELECT COUNT(*) FROM skills")->fetchColumn();
$stats['messages'] = $pdo->query("SELECT COUNT(*) FROM messages")->fetchColumn();
$stats['unread_messages'] = $pdo->query("SELECT COUNT(*) FROM messages WHERE is_read = 0")->fetchColumn();
$stats['experience'] = $pdo->query("SELECT COUNT(*) FROM experience")->fetchColumn();
$stats['subscribers'] = $pdo->query("SELECT COUNT(*) FROM subscribers")->fetchColumn();

// Get recent messages
$recentMessages = $pdo->query("SELECT * FROM messages ORDER BY created_at DESC LIMIT 5")->fetchAll();

// Get recent projects
$recentProjects = $pdo->query("SELECT * FROM projects ORDER BY created_at DESC LIMIT 5")->fetchAll();

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Admin Panel</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <aside class="admin-sidebar" id="adminSidebar">
            <div class="sidebar-header">
                <a href="index.php" class="logo">Hafsat<span style="color: var(--admin-primary);">.</span>Dev</a>
                <button class="sidebar-toggle" onclick="toggleSidebar()">
                    <i class="fas fa-bars"></i>
                </button>
            </div>

            <div class="sidebar-user">
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['admin_name']); ?>&background=00d4ff&color=fff" alt="Admin">
                <div class="sidebar-user-info">
                    <h4><?php echo htmlspecialchars($_SESSION['admin_name']); ?></h4>
                    <p><?php echo ucfirst($_SESSION['admin_role']); ?></p>
                </div>
            </div>

            <nav class="sidebar-nav">
                <ul>
                    <li><a href="index.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="projects.php"><i class="fas fa-project-diagram"></i> Projects</a></li>
                    <li><a href="skills.php"><i class="fas fa-code"></i> Skills</a></li>
                    <li><a href="messages.php"><i class="fas fa-envelope"></i> Messages <?php if($stats['unread_messages'] > 0): ?><span class="badge badge-danger" style="margin-left:auto;font-size:0.7rem;"><?php echo $stats['unread_messages']; ?></span><?php endif; ?></a></li>
                    <li><a href="experience.php"><i class="fas fa-briefcase"></i> Experience</a></li>
                    <li><a href="services.php"><i class="fas fa-cogs"></i> Services</a></li>
                    <li><a href="testimonials.php"><i class="fas fa-quote-left"></i> Testimonials</a></li>
                    <li><a href="subscribers.php"><i class="fas fa-users"></i> Subscribers</a></li>
                    <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                </ul>
            </nav>

            <div class="sidebar-footer">
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>

        <!-- Overlay for mobile -->
        <div class="admin-overlay" id="adminOverlay" onclick="toggleSidebar()"></div>

        <!-- Main Content -->
        <main class="admin-main" id="adminMain">
            <!-- Top Bar -->
            <div class="admin-topbar">
                <div class="topbar-title">
                    <h1>Dashboard</h1>
                    <p>Welcome back, <?php echo htmlspecialchars($_SESSION['admin_name']); ?>!</p>
                </div>
                <div class="topbar-actions">
                    <a href="messages.php" class="topbar-btn">
                        <i class="fas fa-envelope"></i>
                        <?php if($stats['unread_messages'] > 0): ?>
                            <span class="badge"><?php echo $stats['unread_messages']; ?></span>
                        <?php endif; ?>
                    </a>
                    <a href="../index.html" target="_blank" class="topbar-btn" title="View Website">
                        <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>
            </div>

            <!-- Content -->
            <div class="admin-content">
                <?php if ($flash): ?>
                    <div class="admin-alert admin-alert-<?php echo $flash['type']; ?>">
                        <i class="fas fa-<?php echo $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                        <span><?php echo $flash['message']; ?></span>
                    </div>
                <?php endif; ?>

                <!-- Stats Cards -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon blue"><i class="fas fa-project-diagram"></i></div>
                        <div class="stat-info">
                            <h3><?php echo $stats['projects']; ?></h3>
                            <p>Total Projects</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon green"><i class="fas fa-code"></i></div>
                        <div class="stat-info">
                            <h3><?php echo $stats['skills']; ?></h3>
                            <p>Skills</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon orange"><i class="fas fa-envelope"></i></div>
                        <div class="stat-info">
                            <h3><?php echo $stats['messages']; ?></h3>
                            <p>Messages</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon red"><i class="fas fa-envelope-open"></i></div>
                        <div class="stat-info">
                            <h3><?php echo $stats['unread_messages']; ?></h3>
                            <p>Unread Messages</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon purple"><i class="fas fa-briefcase"></i></div>
                        <div class="stat-info">
                            <h3><?php echo $stats['experience']; ?></h3>
                            <p>Experience</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon cyan"><i class="fas fa-users"></i></div>
                        <div class="stat-info">
                            <h3><?php echo $stats['subscribers']; ?></h3>
                            <p>Subscribers</p>
                        </div>
                    </div>
                </div>

                <!-- Recent Messages -->
                <div class="data-card">
                    <div class="data-card-header">
                        <h3><i class="fas fa-envelope" style="color: var(--admin-primary); margin-right: 0.5rem;"></i> Recent Messages</h3>
                        <a href="messages.php" class="btn-admin btn-admin-secondary" style="font-size: 0.85rem;">
                            <i class="fas fa-arrow-right"></i> View All
                        </a>
                    </div>
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Subject</th>
                                <th>Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($recentMessages) > 0): ?>
                                <?php foreach ($recentMessages as $msg): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($msg['name']); ?></td>
                                        <td><?php echo htmlspecialchars($msg['email']); ?></td>
                                        <td><?php echo htmlspecialchars(substr($msg['subject'], 0, 40)); ?><?php echo strlen($msg['subject']) > 40 ? '...' : ''; ?></td>
                                        <td><?php echo date('M d, Y', strtotime($msg['created_at'])); ?></td>
                                        <td>
                                            <?php if ($msg['is_read']): ?>
                                                <span class="badge badge-success"><i class="fas fa-check"></i> Read</span>
                                            <?php else: ?>
                                                <span class="badge badge-warning"><i class="fas fa-clock"></i> New</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="5" style="text-align: center; color: var(--admin-muted);">No messages yet</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Recent Projects -->
                <div class="data-card">
                    <div class="data-card-header">
                        <h3><i class="fas fa-project-diagram" style="color: var(--admin-primary); margin-right: 0.5rem;"></i> Recent Projects</h3>
                        <a href="projects.php" class="btn-admin btn-admin-secondary" style="font-size: 0.85rem;">
                            <i class="fas fa-arrow-right"></i> View All
                        </a>
                    </div>
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Category</th>
                                <th>Featured</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($recentProjects) > 0): ?>
                                <?php foreach ($recentProjects as $proj): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($proj['title']); ?></td>
                                        <td><?php echo htmlspecialchars($proj['category']); ?></td>
                                        <td>
                                            <?php if ($proj['featured']): ?>
                                                <span class="badge badge-success"><i class="fas fa-star"></i> Yes</span>
                                            <?php else: ?>
                                                <span class="badge badge-info">No</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo date('M d, Y', strtotime($proj['created_at'])); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="4" style="text-align: center; color: var(--admin-muted);">No projects yet</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <script>
        function toggleSidebar() {
            document.getElementById('adminSidebar').classList.toggle('active');
            document.getElementById('adminOverlay').classList.toggle('active');
        }
    </script>
</body>
</html>
