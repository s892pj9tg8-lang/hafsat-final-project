<?php
session_start();
require_once '../includes/db.php';
requireLogin();

$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($action === 'delete' && $id > 0) {
    $pdo->prepare("DELETE FROM subscribers WHERE id = ?")->execute([$id]);
    setFlash('success', 'Subscriber removed!');
    header('Location: subscribers.php'); exit;
}

if ($action === 'toggle' && $id > 0) {
    $pdo->prepare("UPDATE subscribers SET is_active = NOT is_active WHERE id = ?")->execute([$id]);
    setFlash('success', 'Subscriber status updated!');
    header('Location: subscribers.php'); exit;
}

$subscribers = $pdo->query("SELECT * FROM subscribers ORDER BY subscribed_at DESC")->fetchAll();
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subscribers | Admin Panel</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <aside class="admin-sidebar" id="adminSidebar">
            <div class="sidebar-header">
                <a href="index.php" class="logo">Hafsat<span style="color: var(--admin-primary);">.</span>Dev</a>
                <button class="sidebar-toggle" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
            </div>
            <div class="sidebar-user">
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['admin_name']); ?>&background=00d4ff&color=fff" alt="Admin">
                <div class="sidebar-user-info">
                    <h4><?php echo htmlspecialchars($_SESSION['admin_name']); ?></h4>
                    <p><?php echo ucfirst($_SESSION['admin_role']); ?></p>
                </div>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="projects.php"><i class="fas fa-project-diagram"></i> Projects</a></li>
                    <li><a href="skills.php"><i class="fas fa-code"></i> Skills</a></li>
                    <li><a href="messages.php"><i class="fas fa-envelope"></i> Messages</a></li>
                    <li><a href="experience.php"><i class="fas fa-briefcase"></i> Experience</a></li>
                    <li><a href="services.php"><i class="fas fa-cogs"></i> Services</a></li>
                    <li><a href="testimonials.php"><i class="fas fa-quote-left"></i> Testimonials</a></li>
                    <li><a href="subscribers.php" class="active"><i class="fas fa-users"></i> Subscribers</a></li>
                    <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>
        <div class="admin-overlay" id="adminOverlay" onclick="toggleSidebar()"></div>

        <main class="admin-main" id="adminMain">
            <div class="admin-topbar">
                <div class="topbar-title">
                    <h1>Subscribers</h1>
                    <p>Newsletter Subscribers</p>
                </div>
                <div class="topbar-actions">
                    <a href="../index.html" target="_blank" class="topbar-btn"><i class="fas fa-external-link-alt"></i></a>
                </div>
            </div>

            <div class="admin-content">
                <?php if ($flash): ?>
                    <div class="admin-alert admin-alert-<?php echo $flash['type']; ?>">
                        <i class="fas fa-<?php echo $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                        <span><?php echo $flash['message']; ?></span>
                    </div>
                <?php endif; ?>

                <div class="data-card">
                    <div class="data-card-header">
                        <h3><i class="fas fa-users" style="color: var(--admin-primary); margin-right: 0.5rem;"></i> All Subscribers</h3>
                        <div class="data-card-actions">
                            <div class="search-box">
                                <i class="fas fa-search"></i>
                                <input type="text" id="tableSearch" placeholder="Search subscribers...">
                            </div>
                        </div>
                    </div>
                    <table class="admin-table" id="dataTable">
                        <thead>
                            <tr><th>ID</th><th>Email</th><th>Status</th><th>Subscribed</th><th>Actions</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($subscribers as $sub): ?>
                                <tr>
                                    <td>#<?php echo $sub['id']; ?></td>
                                    <td><?php echo htmlspecialchars($sub['email']); ?></td>
                                    <td><?php echo $sub['is_active'] ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>'; ?></td>
                                    <td><?php echo date('M d, Y', strtotime($sub['subscribed_at'])); ?></td>
                                    <td>
                                        <a href="subscribers.php?action=toggle&id=<?php echo $sub['id']; ?>" class="btn-action btn-edit" title="Toggle Status"><i class="fas fa-toggle-<?php echo $sub['is_active'] ? 'on' : 'off'; ?>"></i></a>
                                        <a href="subscribers.php?action=delete&id=<?php echo $sub['id']; ?>" class="btn-action btn-delete" onclick="return confirmDelete()" title="Remove"><i class="fas fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (count($subscribers) === 0): ?>
                                <tr><td colspan="5" style="text-align: center; color: var(--admin-muted); padding: 3rem;">No subscribers yet</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    <script>
        function toggleSidebar() {
            document.getElementById('adminSidebar').classList.toggle('active');
            document.getElementById('adminOverlay').classList.toggle('active');
        }
        function confirmDelete() { return confirm('Remove this subscriber?'); }
        document.getElementById('tableSearch')?.addEventListener('keyup', function() {
            const filter = this.value.toLowerCase();
            document.querySelectorAll('#dataTable tbody tr').forEach(row => {
                row.style.display = row.textContent.toLowerCase().includes(filter) ? '' : 'none';
            });
        });
    </script>
</body>
</html>
