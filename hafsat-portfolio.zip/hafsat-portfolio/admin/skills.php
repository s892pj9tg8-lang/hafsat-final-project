<?php
// Admin Skills Management
session_start();
require_once '../includes/db.php';
requireLogin();

$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Handle Delete
if ($action === 'delete' && $id > 0) {
    $pdo->prepare("DELETE FROM skills WHERE id = ?")->execute([$id]);
    setFlash('success', 'Skill deleted successfully!');
    header('Location: skills.php');
    exit;
}

// Handle Add/Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name']);
    $icon = sanitize($_POST['icon']);
    $icon_color = sanitize($_POST['icon_color']);
    $proficiency = intval($_POST['proficiency']);
    $category = sanitize($_POST['category']);
    $display_order = intval($_POST['display_order']);
    $is_active = isset($_POST['is_active']) ? 1 : 0;

    if (empty($name)) {
        $error = 'Skill name is required.';
    } else {
        if ($id > 0) {
            $pdo->prepare("UPDATE skills SET name=?, icon=?, icon_color=?, proficiency=?, category=?, display_order=?, is_active=? WHERE id=?")
                ->execute([$name, $icon, $icon_color, $proficiency, $category, $display_order, $is_active, $id]);
            setFlash('success', 'Skill updated successfully!');
        } else {
            $pdo->prepare("INSERT INTO skills (name, icon, icon_color, proficiency, category, display_order, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)")
                ->execute([$name, $icon, $icon_color, $proficiency, $category, $display_order, $is_active]);
            setFlash('success', 'Skill added successfully!');
        }
        header('Location: skills.php');
        exit;
    }
}

$skill = null;
if ($action === 'edit' && $id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM skills WHERE id = ?");
    $stmt->execute([$id]);
    $skill = $stmt->fetch();
}

$skills = $pdo->query("SELECT * FROM skills ORDER BY display_order, created_at DESC")->fetchAll();
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Skills | Admin Panel</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <aside class="admin-sidebar" id="adminSidebar">
            <div class="sidebar-header">
                <a href="index.php" class="logo">Hafsat<span style="color: var(--admin-primary);">.</span>Dev</a>
                <button class="sidebar-toggle" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
            </div>
            <div class="sidebar-user">
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['admin_name']); ?>&background=00d4ff&color=fff" alt="Admin">
                <div class="sidebar-user-info">
                    <h4><?php echo htmlspecialchars($_SESSION['admin_name']); ?></h4>
                    <p><?php echo ucfirst($_SESSION['admin_role']); ?></p>
                </div>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="projects.php"><i class="fas fa-project-diagram"></i> Projects</a></li>
                    <li><a href="skills.php" class="active"><i class="fas fa-code"></i> Skills</a></li>
                    <li><a href="messages.php"><i class="fas fa-envelope"></i> Messages</a></li>
                    <li><a href="experience.php"><i class="fas fa-briefcase"></i> Experience</a></li>
                    <li><a href="services.php"><i class="fas fa-cogs"></i> Services</a></li>
                    <li><a href="testimonials.php"><i class="fas fa-quote-left"></i> Testimonials</a></li>
                    <li><a href="subscribers.php"><i class="fas fa-users"></i> Subscribers</a></li>
                    <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>
        <div class="admin-overlay" id="adminOverlay" onclick="toggleSidebar()"></div>

        <main class="admin-main" id="adminMain">
            <div class="admin-topbar">
                <div class="topbar-title">
                    <h1>Manage Skills</h1>
                    <p><?php echo $action === 'add' ? 'Add New Skill' : ($action === 'edit' ? 'Edit Skill' : 'All Skills'); ?></p>
                </div>
                <div class="topbar-actions">
                    <a href="../index.html" target="_blank" class="topbar-btn" title="View Website"><i class="fas fa-external-link-alt"></i></a>
                </div>
            </div>

            <div class="admin-content">
                <?php if ($flash): ?>
                    <div class="admin-alert admin-alert-<?php echo $flash['type']; ?>">
                        <i class="fas fa-<?php echo $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                        <span><?php echo $flash['message']; ?></span>
                    </div>
                <?php endif; ?>

                <?php if (isset($error)): ?>
                    <div class="admin-alert admin-alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo $error; ?></span>
                    </div>
                <?php endif; ?>

                <?php if ($action === 'add' || $action === 'edit'): ?>
                    <div class="data-card">
                        <div class="data-card-header">
                            <h3><?php echo $action === 'edit' ? 'Edit Skill' : 'Add New Skill'; ?></h3>
                            <a href="skills.php" class="btn-admin btn-admin-secondary" style="font-size: 0.85rem;">
                                <i class="fas fa-arrow-left"></i> Back
                            </a>
                        </div>
                        <div style="padding: 2rem;">
                            <form class="admin-form" method="POST" action="">
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="name">Skill Name *</label>
                                        <input type="text" id="name" name="name" required 
                                               value="<?php echo $skill ? htmlspecialchars($skill['name']) : ''; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="icon">Icon Class (Font Awesome)</label>
                                        <input type="text" id="icon" name="icon" placeholder="fas fa-code" 
                                               value="<?php echo $skill ? htmlspecialchars($skill['icon']) : 'fas fa-code'; ?>">
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="icon_color">Icon Color</label>
                                        <input type="text" id="icon_color" name="icon_color" placeholder="#00d4ff" 
                                               value="<?php echo $skill ? htmlspecialchars($skill['icon_color']) : '#00d4ff'; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="proficiency">Proficiency (%)</label>
                                        <input type="number" id="proficiency" name="proficiency" min="0" max="100" 
                                               value="<?php echo $skill ? $skill['proficiency'] : '50'; ?>">
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="category">Category</label>
                                        <select id="category" name="category">
                                            <option value="Technical" <?php echo ($skill && $skill['category'] === 'Technical') ? 'selected' : ''; ?>>Technical</option>
                                            <option value="Frontend" <?php echo ($skill && $skill['category'] === 'Frontend') ? 'selected' : ''; ?>>Frontend</option>
                                            <option value="Backend" <?php echo ($skill && $skill['category'] === 'Backend') ? 'selected' : ''; ?>>Backend</option>
                                            <option value="Design" <?php echo ($skill && $skill['category'] === 'Design') ? 'selected' : ''; ?>>Design</option>
                                            <option value="Tools" <?php echo ($skill && $skill['category'] === 'Tools') ? 'selected' : ''; ?>>Tools</option>
                                            <option value="Soft Skills" <?php echo ($skill && $skill['category'] === 'Soft Skills') ? 'selected' : ''; ?>>Soft Skills</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="display_order">Display Order</label>
                                        <input type="number" id="display_order" name="display_order" min="0" 
                                               value="<?php echo $skill ? $skill['display_order'] : '0'; ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>
                                        <input type="checkbox" name="is_active" value="1" <?php echo (!$skill || $skill['is_active']) ? 'checked' : ''; ?>>
                                        Active
                                    </label>
                                </div>
                                <div style="display: flex; gap: 1rem;">
                                    <button type="submit" class="btn-admin btn-admin-primary">
                                        <i class="fas fa-save"></i> <?php echo $action === 'edit' ? 'Update' : 'Save'; ?>
                                    </button>
                                    <a href="skills.php" class="btn-admin btn-admin-secondary">Cancel</a>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="data-card">
                        <div class="data-card-header">
                            <h3><i class="fas fa-code" style="color: var(--admin-primary); margin-right: 0.5rem;"></i> All Skills</h3>
                            <div class="data-card-actions">
                                <div class="search-box">
                                    <i class="fas fa-search"></i>
                                    <input type="text" id="tableSearch" placeholder="Search skills...">
                                </div>
                                <a href="skills.php?action=add" class="btn-admin btn-admin-primary">
                                    <i class="fas fa-plus"></i> Add Skill
                                </a>
                            </div>
                        </div>
                        <table class="admin-table" id="dataTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Category</th>
                                    <th>Proficiency</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($skills as $s): ?>
                                    <tr>
                                        <td>#<?php echo $s['id']; ?></td>
                                        <td><i class="<?php echo htmlspecialchars($s['icon']); ?>" style="color: <?php echo htmlspecialchars($s['icon_color']); ?>; margin-right: 0.5rem;"></i> <?php echo htmlspecialchars($s['name']); ?></td>
                                        <td><?php echo htmlspecialchars($s['category']); ?></td>
                                        <td>
                                            <div style="background: rgba(255,255,255,0.1); border-radius: 4px; height: 8px; width: 100px; overflow: hidden;">
                                                <div style="background: linear-gradient(90deg, var(--admin-primary), var(--secondary)); height: 100%; width: <?php echo $s['proficiency']; ?>%; border-radius: 4px;"></div>
                                            </div>
                                            <span style="font-size: 0.8rem; color: var(--admin-muted);"><?php echo $s['proficiency']; ?>%</span>
                                        </td>
                                        <td>
                                            <?php if ($s['is_active']): ?>
                                                <span class="badge badge-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge badge-danger">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="skills.php?action=edit&id=<?php echo $s['id']; ?>" class="btn-action btn-edit" title="Edit"><i class="fas fa-edit"></i></a>
                                            <a href="skills.php?action=delete&id=<?php echo $s['id']; ?>" class="btn-action btn-delete" title="Delete" onclick="return confirmDelete()"><i class="fas fa-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
    <script>
        function toggleSidebar() {
            document.getElementById('adminSidebar').classList.toggle('active');
            document.getElementById('adminOverlay').classList.toggle('active');
        }
        function confirmDelete() {
            return confirm('Are you sure you want to delete this skill?');
        }
        document.getElementById('tableSearch')?.addEventListener('keyup', function() {
            const filter = this.value.toLowerCase();
            document.querySelectorAll('#dataTable tbody tr').forEach(row => {
                row.style.display = row.textContent.toLowerCase().includes(filter) ? '' : 'none';
            });
        });
    </script>
</body>
</html>
