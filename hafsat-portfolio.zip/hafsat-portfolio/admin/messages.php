<?php
// Admin Messages Management
session_start();
require_once '../includes/db.php';
requireLogin();

$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Mark as read
if ($action === 'read' && $id > 0) {
    $pdo->prepare("UPDATE messages SET is_read = 1 WHERE id = ?")->execute([$id]);
}

// Mark as replied
if ($action === 'replied' && $id > 0) {
    $pdo->prepare("UPDATE messages SET is_replied = 1 WHERE id = ?")->execute([$id]);
    setFlash('success', 'Message marked as replied!');
    header('Location: messages.php');
    exit;
}

// Delete
if ($action === 'delete' && $id > 0) {
    $pdo->prepare("DELETE FROM messages WHERE id = ?")->execute([$id]);
    setFlash('success', 'Message deleted successfully!');
    header('Location: messages.php');
    exit;
}

// View single message
$message = null;
if ($action === 'view' && $id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM messages WHERE id = ?");
    $stmt->execute([$id]);
    $message = $stmt->fetch();
    // Auto mark as read
    if ($message && !$message['is_read']) {
        $pdo->prepare("UPDATE messages SET is_read = 1 WHERE id = ?")->execute([$id]);
    }
}

$messages = $pdo->query("SELECT * FROM messages ORDER BY created_at DESC")->fetchAll();
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages | Admin Panel</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <aside class="admin-sidebar" id="adminSidebar">
            <div class="sidebar-header">
                <a href="index.php" class="logo">Hafsat<span style="color: var(--admin-primary);">.</span>Dev</a>
                <button class="sidebar-toggle" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
            </div>
            <div class="sidebar-user">
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['admin_name']); ?>&background=00d4ff&color=fff" alt="Admin">
                <div class="sidebar-user-info">
                    <h4><?php echo htmlspecialchars($_SESSION['admin_name']); ?></h4>
                    <p><?php echo ucfirst($_SESSION['admin_role']); ?></p>
                </div>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="projects.php"><i class="fas fa-project-diagram"></i> Projects</a></li>
                    <li><a href="skills.php"><i class="fas fa-code"></i> Skills</a></li>
                    <li><a href="messages.php" class="active"><i class="fas fa-envelope"></i> Messages</a></li>
                    <li><a href="experience.php"><i class="fas fa-briefcase"></i> Experience</a></li>
                    <li><a href="services.php"><i class="fas fa-cogs"></i> Services</a></li>
                    <li><a href="testimonials.php"><i class="fas fa-quote-left"></i> Testimonials</a></li>
                    <li><a href="subscribers.php"><i class="fas fa-users"></i> Subscribers</a></li>
                    <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>
        <div class="admin-overlay" id="adminOverlay" onclick="toggleSidebar()"></div>

        <main class="admin-main" id="adminMain">
            <div class="admin-topbar">
                <div class="topbar-title">
                    <h1>Messages</h1>
                    <p><?php echo $action === 'view' ? 'View Message' : 'All Contact Messages'; ?></p>
                </div>
                <div class="topbar-actions">
                    <a href="../index.html" target="_blank" class="topbar-btn" title="View Website"><i class="fas fa-external-link-alt"></i></a>
                </div>
            </div>

            <div class="admin-content">
                <?php if ($flash): ?>
                    <div class="admin-alert admin-alert-<?php echo $flash['type']; ?>">
                        <i class="fas fa-<?php echo $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                        <span><?php echo $flash['message']; ?></span>
                    </div>
                <?php endif; ?>

                <?php if ($action === 'view' && $message): ?>
                    <div class="data-card">
                        <div class="data-card-header">
                            <h3><i class="fas fa-envelope" style="color: var(--admin-primary); margin-right: 0.5rem;"></i> Message Details</h3>
                            <a href="messages.php" class="btn-admin btn-admin-secondary" style="font-size: 0.85rem;">
                                <i class="fas fa-arrow-left"></i> Back
                            </a>
                        </div>
                        <div style="padding: 2rem;">
                            <div style="margin-bottom: 1.5rem;">
                                <strong style="color: var(--admin-muted); font-size: 0.85rem;">From:</strong>
                                <p style="font-size: 1.1rem; margin-top: 0.3rem;"><?php echo htmlspecialchars($message['name']); ?> <span style="color: var(--admin-muted);">&lt;<?php echo htmlspecialchars($message['email']); ?>&gt;</span></p>
                            </div>
                            <div style="margin-bottom: 1.5rem;">
                                <strong style="color: var(--admin-muted); font-size: 0.85rem;">Subject:</strong>
                                <p style="font-size: 1.1rem; margin-top: 0.3rem;"><?php echo htmlspecialchars($message['subject']); ?></p>
                            </div>
                            <div style="margin-bottom: 1.5rem;">
                                <strong style="color: var(--admin-muted); font-size: 0.85rem;">Date:</strong>
                                <p style="margin-top: 0.3rem;"><?php echo date('F d, Y 	 h:i A', strtotime($message['created_at'])); ?></p>
                            </div>
                            <div style="margin-bottom: 1.5rem;">
                                <strong style="color: var(--admin-muted); font-size: 0.85rem;">Message:</strong>
                                <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--admin-border); border-radius: 12px; padding: 1.5rem; margin-top: 0.5rem; line-height: 1.8;">
                                    <?php echo nl2br(htmlspecialchars($message['message'])); ?>
                                </div>
                            </div>
                            <div style="display: flex; gap: 1rem;">
                                <a href="mailto:<?php echo htmlspecialchars($message['email']); ?>?subject=Re: <?php echo urlencode($message['subject']); ?>" class="btn-admin btn-admin-primary">
                                    <i class="fas fa-reply"></i> Reply
                                </a>
                                <?php if (!$message['is_replied']): ?>
                                    <a href="messages.php?action=replied&id=<?php echo $message['id']; ?>" class="btn-admin btn-admin-secondary">
                                        <i class="fas fa-check"></i> Mark as Replied
                                    </a>
                                <?php endif; ?>
                                <a href="messages.php?action=delete&id=<?php echo $message['id']; ?>" class="btn-admin btn-admin-danger" onclick="return confirmDelete('Delete this message?')">
                                    <i class="fas fa-trash"></i> Delete
                                </a>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="data-card">
                        <div class="data-card-header">
                            <h3><i class="fas fa-envelope" style="color: var(--admin-primary); margin-right: 0.5rem;"></i> All Messages</h3>
                            <div class="search-box">
                                <i class="fas fa-search"></i>
                                <input type="text" id="tableSearch" placeholder="Search messages...">
                            </div>
                        </div>
                        <table class="admin-table" id="dataTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Subject</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($messages as $msg): ?>
                                    <tr style="<?php echo !$msg['is_read'] ? 'background: rgba(0,212,255,0.03);' : ''; ?>">
                                        <td>#<?php echo $msg['id']; ?></td>
                                        <td><strong><?php echo htmlspecialchars($msg['name']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($msg['email']); ?></td>
                                        <td><?php echo htmlspecialchars(substr($msg['subject'], 0, 30)); ?><?php echo strlen($msg['subject']) > 30 ? '...' : ''; ?></td>
                                        <td>
                                            <?php if (!$msg['is_read']): ?>
                                                <span class="badge badge-warning"><i class="fas fa-clock"></i> New</span>
                                            <?php elseif ($msg['is_replied']): ?>
                                                <span class="badge badge-success"><i class="fas fa-check-double"></i> Replied</span>
                                            <?php else: ?>
                                                <span class="badge badge-info"><i class="fas fa-check"></i> Read</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo date('M d, Y', strtotime($msg['created_at'])); ?></td>
                                        <td>
                                            <a href="messages.php?action=view&id=<?php echo $msg['id']; ?>" class="btn-action btn-view" title="View"><i class="fas fa-eye"></i></a>
                                            <a href="messages.php?action=delete&id=<?php echo $msg['id']; ?>" class="btn-action btn-delete" title="Delete" onclick="return confirmDelete()"><i class="fas fa-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (count($messages) === 0): ?>
                                    <tr><td colspan="7" style="text-align: center; color: var(--admin-muted); padding: 3rem;">No messages yet</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
    <script>
        function toggleSidebar() {
            document.getElementById('adminSidebar').classList.toggle('active');
            document.getElementById('adminOverlay').classList.toggle('active');
        }
        function confirmDelete(msg) {
            return confirm(msg || 'Are you sure?');
        }
        document.getElementById('tableSearch')?.addEventListener('keyup', function() {
            const filter = this.value.toLowerCase();
            document.querySelectorAll('#dataTable tbody tr').forEach(row => {
                row.style.display = row.textContent.toLowerCase().includes(filter) ? '' : 'none';
            });
        });
    </script>
</body>
</html>
