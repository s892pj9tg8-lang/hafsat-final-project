<?php
session_start();
require_once '../includes/db.php';
requireLogin();

$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($action === 'delete' && $id > 0) {
    $pdo->prepare("DELETE FROM experience WHERE id = ?")->execute([$id]);
    setFlash('success', 'Experience entry deleted!');
    header('Location: experience.php'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = sanitize($_POST['role']);
    $company = sanitize($_POST['company']);
    $location = sanitize($_POST['location']);
    $start_date = $_POST['start_date'];
    $end_date = !empty($_POST['end_date']) ? $_POST['end_date'] : null;
    $is_current = isset($_POST['is_current']) ? 1 : 0;
    $description = sanitize($_POST['description']);
    $tags = sanitize($_POST['tags']);
    $sort_order = intval($_POST['sort_order']);

    if (empty($role) || empty($company) || empty($description)) {
        $error = 'Role, company, and description are required.';
    } else {
        if ($id > 0) {
            $pdo->prepare("UPDATE experience SET role=?, company=?, location=?, start_date=?, end_date=?, is_current=?, description=?, tags=?, sort_order=? WHERE id=?")
                ->execute([$role, $company, $location, $start_date, $end_date, $is_current, $description, $tags, $sort_order, $id]);
            setFlash('success', 'Experience updated!');
        } else {
            $pdo->prepare("INSERT INTO experience (role, company, location, start_date, end_date, is_current, description, tags, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")
                ->execute([$role, $company, $location, $start_date, $end_date, $is_current, $description, $tags, $sort_order]);
            setFlash('success', 'Experience added!');
        }
        header('Location: experience.php'); exit;
    }
}

$exp = null;
if ($action === 'edit' && $id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM experience WHERE id = ?");
    $stmt->execute([$id]);
    $exp = $stmt->fetch();
}

$experiences = $pdo->query("SELECT * FROM experience ORDER BY sort_order, start_date DESC")->fetchAll();
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Experience | Admin Panel</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <aside class="admin-sidebar" id="adminSidebar">
            <div class="sidebar-header">
                <a href="index.php" class="logo">Hafsat<span style="color: var(--admin-primary);">.</span>Dev</a>
                <button class="sidebar-toggle" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
            </div>
            <div class="sidebar-user">
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['admin_name']); ?>&background=00d4ff&color=fff" alt="Admin">
                <div class="sidebar-user-info">
                    <h4><?php echo htmlspecialchars($_SESSION['admin_name']); ?></h4>
                    <p><?php echo ucfirst($_SESSION['admin_role']); ?></p>
                </div>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="projects.php"><i class="fas fa-project-diagram"></i> Projects</a></li>
                    <li><a href="skills.php"><i class="fas fa-code"></i> Skills</a></li>
                    <li><a href="messages.php"><i class="fas fa-envelope"></i> Messages</a></li>
                    <li><a href="experience.php" class="active"><i class="fas fa-briefcase"></i> Experience</a></li>
                    <li><a href="services.php"><i class="fas fa-cogs"></i> Services</a></li>
                    <li><a href="testimonials.php"><i class="fas fa-quote-left"></i> Testimonials</a></li>
                    <li><a href="subscribers.php"><i class="fas fa-users"></i> Subscribers</a></li>
                    <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>
        <div class="admin-overlay" id="adminOverlay" onclick="toggleSidebar()"></div>

        <main class="admin-main" id="adminMain">
            <div class="admin-topbar">
                <div class="topbar-title">
                    <h1>Experience</h1>
                    <p><?php echo $action === 'add' ? 'Add New' : ($action === 'edit' ? 'Edit Entry' : 'All Experience'); ?></p>
                </div>
                <div class="topbar-actions">
                    <a href="../index.html" target="_blank" class="topbar-btn"><i class="fas fa-external-link-alt"></i></a>
                </div>
            </div>

            <div class="admin-content">
                <?php if ($flash): ?>
                    <div class="admin-alert admin-alert-<?php echo $flash['type']; ?>">
                        <i class="fas fa-<?php echo $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                        <span><?php echo $flash['message']; ?></span>
                    </div>
                <?php endif; ?>

                <?php if (isset($error)): ?>
                    <div class="admin-alert admin-alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo $error; ?></span>
                    </div>
                <?php endif; ?>

                <?php if ($action === 'add' || $action === 'edit'): ?>
                    <div class="data-card">
                        <div class="data-card-header">
                            <h3><?php echo $action === 'edit' ? 'Edit Experience' : 'Add Experience'; ?></h3>
                            <a href="experience.php" class="btn-admin btn-admin-secondary" style="font-size: 0.85rem;"><i class="fas fa-arrow-left"></i> Back</a>
                        </div>
                        <div style="padding: 2rem;">
                            <form class="admin-form" method="POST" action="">
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="role">Role/Position *</label>
                                        <input type="text" id="role" name="role" required value="<?php echo $exp ? htmlspecialchars($exp['role']) : ''; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="company">Company/Organization *</label>
                                        <input type="text" id="company" name="company" required value="<?php echo $exp ? htmlspecialchars($exp['company']) : ''; ?>">
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="location">Location</label>
                                        <input type="text" id="location" name="location" value="<?php echo $exp ? htmlspecialchars($exp['location']) : ''; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="sort_order">Sort Order</label>
                                        <input type="number" id="sort_order" name="sort_order" min="0" value="<?php echo $exp ? $exp['sort_order'] : '0'; ?>">
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="start_date">Start Date *</label>
                                        <input type="date" id="start_date" name="start_date" required value="<?php echo $exp ? $exp['start_date'] : ''; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="end_date">End Date</label>
                                        <input type="date" id="end_date" name="end_date" value="<?php echo $exp ? $exp['end_date'] : ''; ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>
                                        <input type="checkbox" name="is_current" value="1" <?php echo ($exp && $exp['is_current']) ? 'checked' : ''; ?>>
                                        Current Position
                                    </label>
                                </div>
                                <div class="form-group">
                                    <label for="description">Description *</label>
                                    <textarea id="description" name="description" required><?php echo $exp ? htmlspecialchars($exp['description']) : ''; ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="tags">Tags (comma separated)</label>
                                    <input type="text" id="tags" name="tags" placeholder="PHP, MySQL, Leadership" value="<?php echo $exp ? htmlspecialchars($exp['tags']) : ''; ?>">
                                </div>
                                <div style="display: flex; gap: 1rem;">
                                    <button type="submit" class="btn-admin btn-admin-primary"><i class="fas fa-save"></i> <?php echo $action === 'edit' ? 'Update' : 'Save'; ?></button>
                                    <a href="experience.php" class="btn-admin btn-admin-secondary">Cancel</a>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="data-card">
                        <div class="data-card-header">
                            <h3><i class="fas fa-briefcase" style="color: var(--admin-primary); margin-right: 0.5rem;"></i> Experience</h3>
                            <div class="data-card-actions">
                                <div class="search-box">
                                    <i class="fas fa-search"></i>
                                    <input type="text" id="tableSearch" placeholder="Search...">
                                </div>
                                <a href="experience.php?action=add" class="btn-admin btn-admin-primary"><i class="fas fa-plus"></i> Add</a>
                            </div>
                        </div>
                        <table class="admin-table" id="dataTable">
                            <thead>
                                <tr><th>ID</th><th>Role</th><th>Company</th><th>Period</th><th>Current</th><th>Actions</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($experiences as $e): ?>
                                    <tr>
                                        <td>#<?php echo $e['id']; ?></td>
                                        <td><?php echo htmlspecialchars($e['role']); ?></td>
                                        <td><?php echo htmlspecialchars($e['company']); ?></td>
                                        <td><?php echo date('M Y', strtotime($e['start_date'])); ?> - <?php echo $e['is_current'] ? 'Present' : ($e['end_date'] ? date('M Y', strtotime($e['end_date'])) : '-'); ?></td>
                                        <td><?php echo $e['is_current'] ? '<span class="badge badge-success">Yes</span>' : '<span class="badge badge-info">No</span>'; ?></td>
                                        <td>
                                            <a href="experience.php?action=edit&id=<?php echo $e['id']; ?>" class="btn-action btn-edit"><i class="fas fa-edit"></i></a>
                                            <a href="experience.php?action=delete&id=<?php echo $e['id']; ?>" class="btn-action btn-delete" onclick="return confirmDelete()"><i class="fas fa-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
    <script>
        function toggleSidebar() {
            document.getElementById('adminSidebar').classList.toggle('active');
            document.getElementById('adminOverlay').classList.toggle('active');
        }
        function confirmDelete() { return confirm('Are you sure?'); }
        document.getElementById('tableSearch')?.addEventListener('keyup', function() {
            const filter = this.value.toLowerCase();
            document.querySelectorAll('#dataTable tbody tr').forEach(row => {
                row.style.display = row.textContent.toLowerCase().includes(filter) ? '' : 'none';
            });
        });
    </script>
</body>
</html>
