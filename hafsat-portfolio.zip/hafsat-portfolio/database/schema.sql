-- ============================================
-- Hafsat Samaila Abubakar - Portfolio Database
-- Complete MySQL Schema with Sample Data
-- ============================================

CREATE DATABASE IF NOT EXISTS hafsat_portfolio CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hafsat_portfolio;

-- ============================================
-- USERS TABLE (Admin Authentication)
-- ============================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role ENUM('admin', 'editor') DEFAULT 'admin',
    avatar VARCHAR(255) DEFAULT NULL,
    last_login DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- PROJECTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    slug VARCHAR(200) NOT NULL UNIQUE,
    description TEXT NOT NULL,
    image VARCHAR(255) DEFAULT NULL,
    technologies TEXT DEFAULT NULL,
    live_url VARCHAR(255) DEFAULT NULL,
    github_url VARCHAR(255) DEFAULT NULL,
    category VARCHAR(100) DEFAULT 'Web Development',
    featured TINYINT(1) DEFAULT 0,
    sort_order INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- SKILLS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS skills (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    icon VARCHAR(50) DEFAULT 'fas fa-code',
    icon_color VARCHAR(20) DEFAULT '#00d4ff',
    proficiency INT NOT NULL DEFAULT 50,
    category VARCHAR(50) DEFAULT 'Technical',
    display_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- MESSAGES TABLE (Contact Form)
-- ============================================
CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    subject VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    is_replied TINYINT(1) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- EXPERIENCE TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS experience (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role VARCHAR(200) NOT NULL,
    company VARCHAR(200) NOT NULL,
    location VARCHAR(100) DEFAULT NULL,
    start_date DATE NOT NULL,
    end_date DATE DEFAULT NULL,
    is_current TINYINT(1) DEFAULT 0,
    description TEXT NOT NULL,
    tags TEXT DEFAULT NULL,
    sort_order INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- SERVICES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    icon VARCHAR(50) DEFAULT 'fas fa-code',
    description TEXT NOT NULL,
    display_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TESTIMONIALS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS testimonials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    role VARCHAR(100) NOT NULL,
    company VARCHAR(100) DEFAULT NULL,
    image VARCHAR(255) DEFAULT NULL,
    content TEXT NOT NULL,
    rating INT DEFAULT 5,
    is_active TINYINT(1) DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- SUBSCRIBERS TABLE (Newsletter)
-- ============================================
CREATE TABLE IF NOT EXISTS subscribers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    is_active TINYINT(1) DEFAULT 1,
    subscribed_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- SITE SETTINGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- INSERT SAMPLE DATA
-- ============================================

-- Admin User (password: admin123)
INSERT INTO users (username, email, password_hash, full_name, role) VALUES
('admin', 'admin@hafsat.dev', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Hafsat Samaila Abubakar', 'admin');

-- Sample Projects
INSERT INTO projects (title, slug, description, image, technologies, live_url, github_url, category, featured, sort_order) VALUES
('Student Management System', 'student-management-system', 'A comprehensive web-based system for managing student records, academic grades, attendance tracking, course enrollment, and report generation for educational institutions.', 'project1.jpg', 'PHP, MySQL, JavaScript, Bootstrap, jQuery', '#', '#', 'Web Application', 1, 1),
('Gym Management System', 'gym-management-system', 'Complete fitness center management solution featuring membership management, class scheduling, trainer assignments, payment processing, and progress tracking dashboards.', 'project2.jpg', 'PHP, MySQL, jQuery, CSS3, Chart.js', '#', '#', 'Web Application', 1, 2),
('Event Booking System', 'event-booking-system', 'Online event ticketing and reservation platform with real-time seat availability, secure payment integration, QR code generation, and automated email confirmations.', 'project3.jpg', 'PHP, MySQL, AJAX, Stripe API, PHPMailer', '#', '#', 'Web Application', 1, 3),
('E-Commerce Website', 'e-commerce-website', 'Full-featured online store with product catalog, shopping cart, user authentication, order management, payment gateway integration, and admin dashboard.', 'project4.jpg', 'PHP, MySQL, JavaScript, PayPal API, Bootstrap', '#', '#', 'E-Commerce', 1, 4),
('Personal Portfolio Website', 'personal-portfolio-website', 'A modern, responsive portfolio website with dark theme, particle animations, contact form with database storage, admin panel, and dynamic content management.', 'project5.jpg', 'HTML5, CSS3, JavaScript, PHP, MySQL', '#', '#', 'Portfolio', 1, 5),
('Attendance Management System', 'attendance-management-system', 'Automated attendance tracking system with QR code generation, real-time reporting, leave management, and comprehensive analytics dashboard for organizations.', 'project6.jpg', 'PHP, MySQL, JavaScript, Ajax, DataTables', '#', '#', 'Web Application', 0, 6);

-- Sample Skills
INSERT INTO skills (name, icon, icon_color, proficiency, category, display_order) VALUES
('HTML5', 'fab fa-html5', '#e34c26', 95, 'Frontend', 1),
('CSS3', 'fab fa-css3-alt', '#264de4', 90, 'Frontend', 2),
('JavaScript', 'fab fa-js', '#f7df1e', 85, 'Frontend', 3),
('PHP', 'fab fa-php', '#777bb4', 88, 'Backend', 4),
('MySQL', 'fas fa-database', '#00758f', 82, 'Backend', 5),
('Responsive Design', 'fas fa-mobile-alt', '#00d4ff', 92, 'Design', 6),
('UI/UX Design', 'fas fa-paint-brush', '#f472b6', 80, 'Design', 7),
('Git & GitHub', 'fab fa-git-alt', '#f05032', 85, 'Tools', 8),
('Database Management', 'fas fa-server', '#a855f7', 78, 'Backend', 9),
('Problem Solving', 'fas fa-brain', '#00d4ff', 90, 'Soft Skills', 10);

-- Sample Experience
INSERT INTO experience (role, company, location, start_date, end_date, is_current, description, tags, sort_order) VALUES
('Full-Stack Developer Intern', 'Tech Innovations Ltd.', 'Lagos, Nigeria', '2025-01-01', NULL, 1, 'Developing and maintaining web applications using PHP, MySQL, and JavaScript. Collaborating with senior developers on enterprise-level projects. Implementing RESTful APIs and optimizing database queries.', 'PHP, MySQL, JavaScript, REST API, Git', 1),
('Freelance Web Developer', 'Self-Employed', 'Remote', '2024-06-01', '2024-12-31', 0, 'Delivered custom web solutions for small businesses and startups. Built e-commerce platforms, portfolio websites, and management systems. Managed client relationships and project timelines independently.', 'HTML/CSS, PHP, MySQL, jQuery, Bootstrap', 2),
('Junior Developer Intern', 'Digital Solutions Inc.', 'Abuja, Nigeria', '2024-01-01', '2024-05-31', 0, 'Assisted in developing frontend components and backend functionality. Participated in code reviews and agile development processes. Gained hands-on experience with version control and deployment workflows.', 'HTML5, CSS3, JavaScript, PHP, MySQL', 3),
('Academic Project Lead', 'University Project Team', 'University Campus', '2023-09-01', '2023-12-31', 0, 'Led a team of 4 students in developing a Student Management System. Managed project planning, task allocation, and code integration. Presented the project to faculty and received top marks.', 'Team Leadership, PHP, MySQL, Project Management', 4);

-- Sample Services
INSERT INTO services (title, icon, description, display_order) VALUES
('Web Development', 'fas fa-code', 'Custom web applications built with modern technologies. From simple landing pages to complex web platforms, I deliver scalable solutions that drive results.', 1),
('Frontend Development', 'fas fa-laptop-code', 'Responsive, interactive user interfaces with HTML5, CSS3, JavaScript, and modern frameworks. Pixel-perfect implementations that work flawlessly across all devices.', 2),
('Backend Development', 'fas fa-server', 'Robust server-side solutions with PHP, secure API development, authentication systems, and efficient data processing pipelines for high-performance applications.', 3),
('Database Design', 'fas fa-database', 'Optimized database architecture with MySQL, including schema design, query optimization, data normalization, and secure data handling practices.', 4),
('UI/UX Design', 'fas fa-paint-brush', 'User-centered design with wireframing, prototyping, and visual design. Creating intuitive interfaces that enhance user experience and engagement.', 5),
('Website Maintenance', 'fas fa-tools', 'Ongoing support, updates, security patches, performance optimization, and content management to keep your website running smoothly.', 6);

-- Sample Testimonials
INSERT INTO testimonials (name, role, company, image, content, rating) VALUES
('Dr. Ahmad Ibrahim', 'CEO', 'Tech Solutions Ltd.', 'client1.jpg', 'Hafsat delivered an exceptional e-commerce platform that exceeded our expectations. Her attention to detail and technical expertise are remarkable.', 5),
('Prof. Fatima Abdullahi', 'University Administrator', 'State University', 'client2.jpg', 'Working with Hafsat was a pleasure. She built our student management system with incredible efficiency and the UI is simply beautiful.', 5),
('Malam Usman Bello', 'Gym Owner', 'FitLife Gym', 'client3.jpg', 'The gym management system Hafsat developed has transformed how we operate. Professional, reliable, and highly skilled developer.', 5);

-- Site Settings
INSERT INTO settings (setting_key, setting_value) VALUES
('site_title', 'Hafsat Samaila Abubakar | Software Engineer'),
('site_description', 'Portfolio of Hafsat Samaila Abubakar - Software Engineering Student & Full-Stack Developer'),
('contact_email', 'hafsat@example.com'),
('contact_phone', '+234 800 000 0000'),
('contact_location', 'Nigeria'),
('google_maps_embed', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31509693.6220375!2d-12.3923279!3d9.145!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x104e0baf7da48d0d%3A0x99a8fe4168c6d001!2sNigeria!5e0!3m2!1sen!2s!4v1700000000000');
