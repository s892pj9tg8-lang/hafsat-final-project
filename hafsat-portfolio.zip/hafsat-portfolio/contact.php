<?php
// Contact Page - Hafsat Samaila Abubakar Portfolio
session_start();
require_once 'includes/db.php';

$success = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = isset($_POST['name']) ? trim(htmlspecialchars($_POST['name'])) : '';
    $email = isset($_POST['email']) ? trim(htmlspecialchars($_POST['email'])) : '';
    $subject = isset($_POST['subject']) ? trim(htmlspecialchars($_POST['subject'])) : '';
    $message = isset($_POST['message']) ? trim(htmlspecialchars($_POST['message'])) : '';

    // Validation
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($message) < 10) {
        $error = 'Message must be at least 10 characters long.';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO messages (name, email, subject, message, created_at) VALUES (?, ?, ?, ?, NOW())");
            $stmt->execute([$name, $email, $subject, $message]);
            $success = 'Thank you! Your message has been sent successfully. I will get back to you soon.';

            // Clear form
            $name = $email = $subject = $message = '';
        } catch (PDOException $e) {
            $error = 'Something went wrong. Please try again later.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Contact Hafsat Samaila Abubakar - Software Engineer">
    <title>Contact | Hafsat Samaila Abubakar</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Fira+Code:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="loading-screen">
        <div class="loader"></div>
        <p class="loading-text">Loading</p>
    </div>

    <canvas id="particles-canvas"></canvas>

    <nav class="navbar">
        <a href="index.html" class="logo">Hafsat<span>.</span>Dev</a>
        <ul class="nav-links">
            <li><a href="index.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="projects.html">Projects</a></li>
            <li><a href="services.html">Services</a></li>
            <li><a href="experience.html">Experience</a></li>
            <li><a href="contact.php" class="active">Contact</a></li>
            <li><button class="theme-toggle" aria-label="Toggle theme"><i class="fas fa-moon"></i></button></li>
        </ul>
        <button class="hamburger" aria-label="Menu"><span></span><span></span><span></span></button>
    </nav>

    <!-- Contact Hero -->
    <section class="hero" style="min-height: 50vh; padding-top: 10rem;">
        <div class="hero-container" style="text-align: center;">
            <div class="hero-content" style="animation: fadeInUp 1s ease-out;">
                <p class="hero-greeting">Get In Touch</p>
                <h1 class="hero-title">Contact <span class="highlight">Me</span></h1>
                <p class="hero-description" style="margin: 0 auto;">
                    Have a project in mind or just want to say hello? I'd love to hear from you.
                </p>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="section">
        <div class="contact-grid">
            <!-- Contact Info -->
            <div class="contact-info fade-in-up">
                <h3>Let's <span>Talk</span></h3>
                <p>Whether you have a question, a project proposal, or just want to connect, feel free to reach out. I'm always open to discussing new projects and opportunities.</p>

                <div class="contact-details">
                    <div class="contact-detail">
                        <i class="fas fa-envelope"></i>
                        <div>
                            <strong>Email</strong>
                            <span>hafsat@example.com</span>
                        </div>
                    </div>
                    <div class="contact-detail">
                        <i class="fas fa-phone"></i>
                        <div>
                            <strong>Phone</strong>
                            <span>+234 800 000 0000</span>
                        </div>
                    </div>
                    <div class="contact-detail">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <strong>Location</strong>
                            <span>Nigeria</span>
                        </div>
                    </div>
                    <div class="contact-detail">
                        <i class="fas fa-clock"></i>
                        <div>
                            <strong>Availability</strong>
                            <span>Mon - Fri, 9AM - 6PM</span>
                        </div>
                    </div>
                </div>

                <div class="social-links" style="margin-top: 1rem;">
                    <a href="https://github.com" target="_blank" aria-label="GitHub"><i class="fab fa-github"></i></a>
                    <a href="https://linkedin.com" target="_blank" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                    <a href="https://twitter.com" target="_blank" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                    <a href="https://instagram.com" target="_blank" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="https://wa.me/2348000000000" target="_blank" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="contact-form fade-in-up">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <span><?php echo $success; ?></span>
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo $error; ?></span>
                    </div>
                <?php endif; ?>

                <form action="contact.php" method="POST" data-validate>
                    <div class="form-group">
                        <label for="name">Your Name *</label>
                        <input type="text" id="name" name="name" placeholder="John Doe" required 
                               value="<?php echo isset($name) ? htmlspecialchars($name) : ''; ?>">
                    </div>
                    <div class="form-group">
                        <label for="email">Your Email *</label>
                        <input type="email" id="email" name="email" placeholder="john@example.com" required
                               value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>">
                    </div>
                    <div class="form-group">
                        <label for="subject">Subject *</label>
                        <input type="text" id="subject" name="subject" placeholder="Project Inquiry" required
                               value="<?php echo isset($subject) ? htmlspecialchars($subject) : ''; ?>">
                    </div>
                    <div class="form-group">
                        <label for="message">Your Message *</label>
                        <textarea id="message" name="message" placeholder="Tell me about your project..." required><?php echo isset($message) ? htmlspecialchars($message) : ''; ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-paper-plane"></i> Send Message
                    </button>
                </form>
            </div>
        </div>

        <!-- Map -->
        <div class="map-container fade-in-up" style="margin-top: 4rem;">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31509693.6220375!2d-12.3923279!3d9.145!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x104e0baf7da48d0d%3A0x99a8fe4168c6d001!2sNigeria!5e0!3m2!1sen!2s!4v1700000000000" 
                    allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="section">
        <div class="section-header fade-in-up">
            <p class="section-label">FAQ</p>
            <h2 class="section-title">Frequently Asked <span>Questions</span></h2>
            <p class="section-subtitle">Common questions about working with me.</p>
        </div>
        <div class="faq-container">
            <div class="faq-item fade-in-up">
                <div class="faq-question">
                    <span>What technologies do you specialize in?</span>
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    <p>I specialize in full-stack web development using HTML5, CSS3, JavaScript, PHP, and MySQL. I'm also experienced with responsive design, UI/UX principles, and modern CSS frameworks like Bootstrap and Tailwind CSS.</p>
                </div>
            </div>
            <div class="faq-item fade-in-up">
                <div class="faq-question">
                    <span>How long does a typical project take?</span>
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    <p>Project timelines vary based on complexity. A simple website might take 1-2 weeks, while a complex web application could take 4-8 weeks. I'll provide a detailed timeline during our initial consultation.</p>
                </div>
            </div>
            <div class="faq-item fade-in-up">
                <div class="faq-question">
                    <span>Do you offer ongoing maintenance?</span>
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    <p>Yes! I offer website maintenance packages that include regular updates, security patches, performance optimization, and content updates. This ensures your website stays secure and up-to-date.</p>
                </div>
            </div>
            <div class="faq-item fade-in-up">
                <div class="faq-question">
                    <span>What is your pricing structure?</span>
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    <p>Pricing depends on project scope and requirements. I offer both fixed-price and hourly rates. Contact me with your project details for a customized quote that fits your budget.</p>
                </div>
            </div>
            <div class="faq-item fade-in-up">
                <div class="faq-question">
                    <span>Can you work with existing codebases?</span>
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    <p>Absolutely! I can work with existing codebases, add new features, fix bugs, or refactor code for better performance. I'll review your current setup and provide recommendations.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-grid">
            <div class="footer-brand">
                <a href="index.html" class="logo">Hafsat<span>.</span>Dev</a>
                <p>Building digital experiences that make a difference.</p>
                <div class="footer-social">
                    <a href="https://github.com" target="_blank"><i class="fab fa-github"></i></a>
                    <a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                    <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                    <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            <div class="footer-links">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="projects.html">Projects</a></li>
                    <li><a href="services.html">Services</a></li>
                </ul>
            </div>
            <div class="footer-links">
                <h4>Services</h4>
                <ul>
                    <li><a href="services.html">Web Development</a></li>
                    <li><a href="services.html">Frontend Dev</a></li>
                    <li><a href="services.html">Backend Dev</a></li>
                    <li><a href="services.html">UI/UX Design</a></li>
                </ul>
            </div>
            <div class="footer-links">
                <h4>Contact</h4>
                <ul>
                    <li><a href="mailto:hafsat@example.com">hafsat@example.com</a></li>
                    <li><a href="tel:+2348000000000">+234 800 000 0000</a></li>
                    <li><a href="contact.php">Send Message</a></li>
                    <li><a href="admin/login.php">Admin Panel</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 Hafsat Samaila Abubakar. All Rights Reserved.</p>
        </div>
    </footer>

    <button class="scroll-top" aria-label="Scroll to top"><i class="fas fa-arrow-up"></i></button>
    <script src="js/main.js"></script>
</body>
</html>
